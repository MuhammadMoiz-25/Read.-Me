// This button is for downloading the CV
let cvBtn = document.getElementById("cvbtn");

// This button is for submitting the form
let submitBtn = document.getElementById("submit");

// When CV button is clicked
cvBtn.addEventListener("click", function () {
    alert("Download successful!");
    // Optionally, download the file if linked:
    // window.location.href = "your-cv.pdf";
});

// When Submit button is clicked
submitBtn.addEventListener("click", function () {
    let email = document.getElementById("email").value.trim();
    let pass = document.getElementById("pass").value.trim();

    if (email === "" || pass === "") {
        alert("Please fill in all details.");
    } else if (!email.includes("@")) {
        alert("Enter a valid email address.");
    } else {
        alert("Logged in successfully!");
    }
});
